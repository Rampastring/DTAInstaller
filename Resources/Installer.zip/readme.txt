The contents of the zip file will be extracted to the user's selected installation directory upon install.
Afterwards, DTA.exe is launched from the target directory.

You should replace this ZIP file with an archive that includes the files that you want the installer to place in the target directory.